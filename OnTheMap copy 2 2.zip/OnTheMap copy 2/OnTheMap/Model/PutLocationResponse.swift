//
//  PutLocationResponse.swift
//  OnTheMap
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 29/04/2022.
//

import Foundation

struct PutLocationResponse: Codable {
    let updatedAt: String
}
