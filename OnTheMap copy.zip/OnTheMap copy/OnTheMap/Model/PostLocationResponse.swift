//
//  PostLocationResponse.swift
//  OnTheMap
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 29/04/2022.
//

import Foundation

struct PostLocationResponse: Codable {
    let createAt: String
    let objectId: String
    
    enum CodingKeys: String, CodingKey {
        case createAt
        case objectId
    }
}
