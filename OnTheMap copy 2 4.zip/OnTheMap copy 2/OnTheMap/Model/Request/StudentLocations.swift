//
//  StudentLocations.swift
//  OnTheMap
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 29/04/2022.
//

import Foundation

struct StudentLocations: Codable {
    
    let results: [StudentLocation]
    
    enum CodingKeys: String, CodingKey {
        case results
    }
}

class StudentsLocationData {
    
    static var studentsData = [StudentLocation]()
}

