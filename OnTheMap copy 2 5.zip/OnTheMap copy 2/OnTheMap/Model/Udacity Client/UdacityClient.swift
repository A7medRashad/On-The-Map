//
//  UdacityClient.swift
//  OnTheMap
//
//  Created by Ahmed Rashad AbdElGhany Haridy on 28/04/2022.
//

import Foundation

class UdacityClient {
    struct Auth {
        static var keyAccount = ""
        static var sessionId = ""
    }
    enum Endpoints {
        static let base = "https://onthemap-api.udacity.com/v1/"
        
        case createSessionId
        case getStudentLocation(Int)
        case getOneStduentLocation(String)
        case postStudentLocation
        case updateStudentLocation(String)
        case getUserData
        case logout
        
        var urlString: String {
            switch self {
            case .createSessionId:
                return Endpoints.base + "session"
            case .getStudentLocation:
                return Endpoints.base + "StudentLocation" + "?limit=100&skip=100&order=-updatedAt"
            case .getOneStduentLocation(let uniqueKey):
                return Endpoints.base + "StudentLocation?uniqueKey=\(uniqueKey)"
            case .postStudentLocation:
                return Endpoints.base + "StudentLocation"
            case .updateStudentLocation:
                return Endpoints.base + "StudentLocation/8ZExGR5uX8"
            case .getUserData:
                return Endpoints.base + "users/" + Auth.keyAccount
            case .logout:
                return Endpoints.base + "session"
            }
        }
        var url: URL {
            return URL(string: urlString)!
        }
    }
    class func login(with email: String, password: String, completion: @escaping (Bool, Error?) -> ()) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"udacity\": {\"username\": \"\(email)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    return completion(false, error)
                }
                return
            }
            let range = 5..<data.count
            let newData = data.subdata(in: range)
            print(String(data: data, encoding: .utf8)!)
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(UserLoginResponse.self, from: newData)
                DispatchQueue.main.async {
                    self.Auth.sessionId = responseObject.session.id
                    self.Auth.keyAccount = responseObject.account.key
                    completion(true, nil)
                }
            }
            catch {
                DispatchQueue.main.async {
                    completion(false, error)
                }
            }
        }
        task.resume()
    }
    class func getStudentLocation(singleStudent: Bool, completion: @escaping ([StudentLocation]?, Error?) -> Void) {
        let session = URLSession.shared
        var request = URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation?order=-updatedAt")!

        if singleStudent {
            request = Endpoints.getOneStduentLocation("1234").url
        } else {
            request = Endpoints.getStudentLocation(0).url
        }
        let task = session.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion([], error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let requestObject = try
                decoder.decode(StudentLocations.self, from: data)
                DispatchQueue.main.async {
                    completion(requestObject.results, nil)
                }
            } catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                    print(error.localizedDescription)
                }
            }
        }
        task.resume()
    }
    class func deleteLoginSession(completion: @escaping (Bool, Error?) -> Void) {
        let url = Endpoints.logout.url
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        
        for  cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie}
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard error == nil else {
                DispatchQueue.main.async {
                    completion(false, error)
                }
                return
            }
            DispatchQueue.main.async {
                completion(true, nil)
            }
             let range = 5..<data!.count
             let newData = data?.subdata(in: range)
             print(String(data: newData!, encoding: .utf8)!)
        }
        task.resume()
    }
    class func getUserData(completion: @escaping (UserData?, Error?) -> Void) {
        let request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/users/3903878747")!)
        let session = URLSession.shared
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let range = 5..<data.count
            let newData = data.subdata(in: range)
            let decoder = JSONDecoder()
            do{
                let requestObject = try decoder.decode(UserData.self, from: newData)
                DispatchQueue.main.async {
                    print(newData)
                    completion(requestObject, nil)
                }
            } catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
            }
            print(String(data: newData, encoding: .utf8)!)
        }
        task.resume()
    }
    class func postStudentLoaction(postLocation: PostLocation, completion: @escaping (PostLocationResponse?, Error?) -> Void) {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"John\", \"lastName\": \"Doe\",\"mapString\": \"Mountain View, CA\", \"mediaURL\": \"https://udacity.com\",\"latitude\": 37.386052, \"longitude\": -122.083851}".data(using: .utf8)
        let session = URLSession.shared
        let body = postLocation
        let encoder = JSONEncoder()
        request.httpBody = try! encoder.encode(body)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    return completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(PostLocationResponse.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                    print(String(data: data, encoding: .utf8)!)
                }
            }
            catch {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
            }
        }
        task.resume()
    }
    class func putStudentLocation(objectID: String, postLocation: PostLocation, completion: @escaping (Bool, Error?) -> Void) {

        let urlString = "https://onthemap-api.udacity.com/v1/StudentLocation/8ZExGR5uX8"
        let url = URL(string: urlString)
        var request = URLRequest(url: Endpoints.updateStudentLocation(objectID).url)
        
        print(request.description)
        
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"John\", \"lastName\": \"Doe\",\"mapString\": \"Cupertino, CA\", \"mediaURL\": \"https://udacity.com\",\"latitude\": 37.322998, \"longitude\": -122.032182}".data(using: .utf8)
        
        let session = URLSession.shared
        let body = postLocation
        let encoder = JSONEncoder()
        request.httpBody = try! encoder.encode(body)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    return completion(false,error)
                }
                return
            }
            let decoder = JSONDecoder()
            do{
                let responseObj = try decoder.decode(PostLocationResponse.self, from: data)
                DispatchQueue.main.async {
                    print("\(responseObj)")
                    completion(true, nil)
                }
            }
            catch {
                DispatchQueue.main.async {
                    completion(false,error)
                }
            }
            print(String(data: data, encoding: .utf8)!)
        }
        task.resume()
    }
}
